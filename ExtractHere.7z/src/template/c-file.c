/*
** Copyright (C) 2019 by Carnegie Mellon University.
**
** @OPENSOURCE_LICENSE_START@
** See license information in ../../LICENSE.txt
** @OPENSOURCE_LICENSE_END@
*/

/*
**  Add your description here
**
*/


#include <silk/silk.h>

RCSIDENT("$Id$");

#include <silk/utils.h>
#error "If you need additional headers, add them here"


/* LOCAL DEFINES AND TYPEDEFS */



/* EXPORTED VARIABLE DEFINITIONS */

#error "Any exported variables should also be declared in a header file."


/* LOCAL VARIABLE DEFINITIONS */



/* LOCAL FUNCTION PROTOTYPES */



/* FUNCTION DEFINITIONS */


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
