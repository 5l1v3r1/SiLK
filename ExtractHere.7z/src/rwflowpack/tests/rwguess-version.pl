#! /usr/bin/perl -w
# STATUS: OK
# TEST: ./rwguess --version

use strict;
use SiLKTests;

my $rwguess = check_silk_app('rwguess');
my $cmd = "$rwguess --version";

exit (check_exit_status($cmd) ? 0 : 1);
