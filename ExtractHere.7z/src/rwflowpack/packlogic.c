#include <silk/silk.h>

/* RCSIDENT("$SiLK: packlogic.c 61f0a18181be 2009-08-07 21:19:06Z mthomas $"); */

/* include the file containing the packing logic */
#include SK_PACKING_LOGIC_PATH

/*
** Local variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
